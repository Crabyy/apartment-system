<template>
  <h2>Dashboard</h2>
</template>

<script>
export default {
  name: 'DashboardComponent',
}
</script>
