<template>
  <h2>Profile</h2>
</template>

<script>
export default {
  name: 'AdminProfile',
}
</script>
